# app.py
from flask import Flask, render_template, request
import re

# Initialize the Flask application
app = Flask(__name__)


# Route for the home page where users input test strings and regex patterns
@app.route('/')
def index():
    return render_template('index.html')


# Route to handle the form submission and perform regex matching
@app.route('/results', methods=['POST'])
def results():
    test_string = request.form['test_string']
    regex = request.form['regex']

    # Perform regex matching with error handling
    try:
        matches = re.findall(regex, test_string)
        if not matches:
            matches = ["No matches found."]
    except re.error:
        matches = ["Invalid regex pattern. Please correct the regex and try again."]

    # Render the same form with results displayed
    return render_template('index.html', matches=matches)


# Route to handle email validation
@app.route('/validate_email', methods=['POST'])
def validate_email():
    email = request.form['email']
    email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

    # Validate the email using regex
    if re.match(email_regex, email):
        result = "Valid Email"
    else:
        result = "Invalid Email"

    # Return the same page with the result of the email validation
    return render_template('index.html', email_result=result)


# Start the Flask application
if __name__ == '__main__':
    app.run(debug=True)
